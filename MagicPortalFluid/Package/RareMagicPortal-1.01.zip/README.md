# RareMagicPortal
Magical Portal Fluid


Tired of Portals be the end all, be all of Valheim? You don't want to unnecessarily restrict which items can be teleported or not? Do you want
to see more PVP or more cooperation between your buddies and their bases?
Well, I've a mod for you!

Set a starting amount of PortalMagicFluid per new character.  This mod changes the recipe for portals and requires a new unique item called PortalMagicFluid. One Magical Portal Fluid per Portal.

Has two Server configurable values:
1)Turn on and off the new portal requirements (true, false)
2) Starting quantity of PortalMagicFluid (default 3)( int 0-250) [ Only applies to brand new character on first spawn in]

Admin can spawn in more items with name ' PortalMagicFluid'

Mod was produced with the hope that multiplayer servers will require more teamwork or more PVP to capture the scare resource. 
Other mods can allow it to be bought at the trader for high prices, gambled on or become rare drops from bosses.
﻿
Could be combined with WayShrine https://www.nexusmods.com/valheim/mods/1298 to create interesting maps.

First Mod: Download and enjoy.
No known conflicts.


Thank you to OdinPlus Team for some useful information.
